package tr.com.srdc.cda2fhir.transform.util.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hl7.fhir.r4.model.Identifier;

import tr.com.srdc.cda2fhir.transform.util.IIdentifierMap;

public class IdentifierMap<T> implements IIdentifierMap<T> {
	private Map<String, InnerIdentifierMap<T>> map = new HashMap<String, InnerIdentifierMap<T>>();

	@Override
	public void put(String fhirType, Identifier identifier, T identifiedValue) {
		InnerIdentifierMap<T> innerMap = map.get(fhirType);
		if (innerMap == null) {
			innerMap = new InnerIdentifierMap<T>();
			map.put(fhirType, innerMap);
		}
		innerMap.put(identifier, identifiedValue);
	}

	@Override
	public void put(String fhirType, List<Identifier> identifiers, T identifiedValue) {
		identifiers.forEach(identifier -> put(fhirType, identifier, identifiedValue));
	}

	@Override
	public void put(String fhirType, String system, String value, T identifiedValue) {
		InnerIdentifierMap<T> innerMap = map.get(fhirType);
		if (innerMap == null) {
			innerMap = new InnerIdentifierMap<T>();
			map.put(fhirType, innerMap);
		}
		innerMap.put(system, value, identifiedValue);
	}

	@Override
	public T get(String fhirType, Identifier identifier) {
		InnerIdentifierMap<T> innerMap = map.get(fhirType);
		if (innerMap != null) {
			return innerMap.get(identifier);
		}
		return null;
	}

	@Override
	public T get(String fhirType, String value) {
		InnerIdentifierMap<T> innerMap = map.get(fhirType);
		if (innerMap != null) {
			return innerMap.get(value);
		}
		return null;
	}

	@Override
	public T get(String fhirType, String system, String value) {
		InnerIdentifierMap<T> innerMap = map.get(fhirType);
		if (innerMap != null) {
			return innerMap.get(system, value);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public void putFromJSONArray(String fhirType, List<Object> identifiers, T identifiedValue) {
		for (Object identifier : identifiers) {
			Map<String, Object> idAsMap = (Map<String, Object>) identifier;
			String system = (String) idAsMap.get("system");
			String value = (String) idAsMap.get("value");

			put(fhirType, system, value, identifiedValue);
		}
	}

	@Override
	public T getFromJSONArray(String fhirType, Map<String, Object> identifier) {
		String system = (String) identifier.get("system");
		String value = (String) identifier.get("value");

		return get(fhirType, system, value);
	}

	@Override
	@SuppressWarnings("unchecked")
	public T getFromJSONArray(String fhirType, List<Object> identifiers) {
		for (Object identifier : identifiers) {
			Map<String, Object> idAsMap = (Map<String, Object>) identifier;
			String system = (String) idAsMap.get("system");
			String value = (String) idAsMap.get("value");

			T result = get(fhirType, system, value);
			if (result != null) {
				return result;
			}
		}
		return null;
	}
}
