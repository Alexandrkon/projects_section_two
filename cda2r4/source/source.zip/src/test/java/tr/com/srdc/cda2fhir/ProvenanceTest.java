package tr.com.srdc.cda2fhir;

import java.security.MessageDigest;

import org.eclipse.emf.ecore.xml.type.internal.DataValue.Base64;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Bundle.BundleEntryComponent;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Device;
import org.hl7.fhir.r4.model.DocumentReference;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Medication;
import org.hl7.fhir.r4.model.Narrative.NarrativeStatus;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Provenance;
import org.hl7.fhir.r4.model.Provenance.ProvenanceEntityRole;
import org.hl7.fhir.r4.model.codesystems.ProvenanceAgentRole;
import org.hl7.fhir.r4.model.codesystems.ProvenanceAgentType;
import org.junit.Assert;
import org.junit.Test;

import tr.com.srdc.cda2fhir.testutil.BundleUtil;
import tr.com.srdc.cda2fhir.transform.ResourceTransformerImpl;

public class ProvenanceTest {

	private static final ResourceTransformerImpl rt = new ResourceTransformerImpl();

	@Test
	public void testProvenance() throws Exception {
		Bundle testBundle = new Bundle();
		IdType orgId = (new IdType("Organization/1"));
		IdType medId = (new IdType("Medication/1"));
		IdType patientId = (new IdType("Patient/1"));

		testBundle.addEntry(new BundleEntryComponent().setResource(new Organization().setIdElement(orgId)));
		testBundle.addEntry(new BundleEntryComponent().setResource(new Medication().setIdElement(medId)));
		testBundle.addEntry(new BundleEntryComponent().setResource(new Patient().setIdElement(patientId)));

		Identifier assemblerDevice = new Identifier();
		assemblerDevice.setValue("Higgs");
		assemblerDevice.setSystem("http://www.amida.com");

		String documentBody = "<ClinicalDoc>Meowmeowmeowmeow</ClinicalDoc>";
		testBundle = rt.tProvenance(testBundle, documentBody, assemblerDevice);

		// Verifies bundle contains the initial resources.
		BundleUtil.findOneResource(testBundle, Organization.class);
		BundleUtil.findOneResource(testBundle, Medication.class);
		BundleUtil.findOneResource(testBundle, Patient.class);

		DocumentReference docRef = BundleUtil.findOneResource(testBundle, DocumentReference.class);

		// Test doc reference.
		Assert.assertEquals(docRef.getStatus().toString(), "CURRENT");
		Assert.assertEquals(docRef.getContent().get(0).getAttachment().getContentType(), "text/plain");
		Assert.assertEquals(docRef.getType().getCoding().get(0).getCode(), "34133-9");

		// Test encoding.
		Assert.assertEquals(docRef.getContent().get(0).getAttachment().getDataElement().getValueAsString(),
				Base64.encode(documentBody.getBytes()));

		// Test hash.
		MessageDigest digest = MessageDigest.getInstance("SHA-1");
		byte[] encodedHash = digest.digest(documentBody.getBytes());
		Assert.assertEquals(docRef.getContent().get(0).getAttachment().getHashElement().getValueAsString(),
				Base64.encode(encodedHash));

		Device device = BundleUtil.findOneResource(testBundle, Device.class);
		Assert.assertEquals(device.getText().getStatusAsString().toLowerCase(),
				NarrativeStatus.GENERATED.toString().toLowerCase());
		Assert.assertEquals(device.getIdentifierFirstRep().getSystem().toLowerCase(),
				assemblerDevice.getSystem().toLowerCase());
		Assert.assertEquals(device.getIdentifierFirstRep().getValue().toLowerCase(),
				assemblerDevice.getValue().toLowerCase());

		Provenance provenance = BundleUtil.findOneResource(testBundle, Provenance.class);
		Assert.assertEquals(provenance.getTarget().get(0).getReference(), orgId.getValue());
		Assert.assertEquals(provenance.getTarget().get(1).getReference(), medId.getValue());
		Assert.assertEquals(provenance.getTarget().get(2).getReference(), patientId.getValue());
		Assert.assertEquals(provenance.getTarget().get(3).getReference().substring(0, 17), "DocumentReference");
		Assert.assertEquals(provenance.getTarget().get(4).getReference().substring(0, 6), "Device");

		Coding roleDevice = provenance.getAgentFirstRep().getType().getCodingFirstRep();
		Assert.assertEquals(roleDevice.getId().substring(0, 6), "Device");
		Assert.assertEquals(roleDevice.getSystem(), ProvenanceAgentType.ASSEMBLER.getSystem());
		Assert.assertEquals(roleDevice.getCode(), ProvenanceAgentType.ASSEMBLER.toCode());
		Assert.assertEquals(roleDevice.getDisplay(), ProvenanceAgentType.ASSEMBLER.getDisplay());

		Coding roleAssembler = provenance.getAgentFirstRep().getRoleFirstRep().getCodingFirstRep();
		Assert.assertEquals(roleAssembler.getId().substring(0, 6), "Device");
		Assert.assertEquals(roleAssembler.getSystem(), ProvenanceAgentRole.ASSEMBLER.getSystem());
		Assert.assertEquals(roleAssembler.getCode(), ProvenanceAgentRole.ASSEMBLER.toCode());
		Assert.assertEquals(roleAssembler.getDisplay(), ProvenanceAgentRole.ASSEMBLER.getDisplay());

		Assert.assertEquals(provenance.getAgentFirstRep().getWho().getReference().substring(0, 6), "Device");

		Assert.assertEquals(provenance.getEntityFirstRep().getWhat().getReference().substring(0, 17),
				"DocumentReference");
		Assert.assertEquals(provenance.getEntityFirstRep().getRole(), ProvenanceEntityRole.SOURCE);
	}
}
